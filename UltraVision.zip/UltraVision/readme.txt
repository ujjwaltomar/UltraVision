****************INSTRUCTIONS FOR GPS***********************

STEP1: Turn on with manual power button.
STEP2: Set the range of sensors.
STEP3: Just walk around and change your direction when the buzzer sounds.
STEP4: Turn off the power button after use.

*****************INTRUCTIONS FOR APP***********************

STEP1: Simply turn on the bluetooth on your device and connect to the hat.
STEP2: Open the UltraVision app.
STEP3: Select the Location Option.
STEP4: Send link to other people which you want to give access.
STEP5: Other User can simply locate the person with UltraVision app.

***********************************************************